﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestrauntApplication
{
    class ItemListModel
    {
        private int _itemId;
        private string _itemName;
        private double _itemPrice;
        private bool _isAvailable;

        public ItemListModel(int itemId, string itemName, double itemPrice, bool isAvailable)
        {
            this._itemId = itemId;
            this._itemName = itemName;
            this._itemPrice = itemPrice;
            this._isAvailable = isAvailable;
        }

        public int ItemId
        {
            set
            {
                _itemId = value;
            }
            get
            {
                return _itemId;
            }
        }
        public string ItemName
        {
            set
            {
                _itemName = value;
            }
            get
            {
                return _itemName;
            }
        }
        public double ItemPrice
        {
            set
            {
                _itemPrice = value;
            }
            get
            {
                return _itemPrice;
            }
        }
        public bool IsAvailable
        {
            set
            {
                _isAvailable = value;
            }
            get
            {
                return _isAvailable;
            }
        }

        //public ItemListModel(int id, string name, double price, bool available)
        //{
        //    this.itemId = id;
        //    this.itemName = name;
        //    this.itemPrice = price;
        //    this.isAvailable = available;
        //}
    }
}
