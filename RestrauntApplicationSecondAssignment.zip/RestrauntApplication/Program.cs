﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace RestrauntApplication
{
    class Program
    {
        
        
        static void Main(string[] args)
        {
           

            //Creating Items for a Reatraunt
            List <ItemListModel> itemObject= new List<ItemListModel>();
            itemObject.Add(new ItemListModel(1, "Idli   ", 40.00, false));
            itemObject.Add(new ItemListModel(2, "Dosa   ", 70.00, true));
            itemObject.Add(new ItemListModel(3, "Biryani",200.00, true));
            itemObject.Add(new ItemListModel(4, "Burger ",120.00, true));
            itemObject.Add(new ItemListModel(5, "Tea    ", 15.00, false));
            
            //creating Tables for Restraunt
            List<TableModel> tableCount = new List<TableModel>();
            tableCount.Add(new TableModel(1,4,true));
            tableCount.Add(new TableModel(2, 6, true));
            tableCount.Add(new TableModel(3, 2, true));
            tableCount.Add(new TableModel(4, 4, true));

            //Creating a Restraunt Object
            RestaurantDetails myRestraunt = new RestaurantDetails("Happy Food Junction","Mihan Branch",itemObject,tableCount);

            //Creating a Customer Object
            CustomerModel firstCustomer = new CustomerModel(1,"Lokesh Kashyap");

            

            Console.WriteLine("Select which menu to display");
            Console.WriteLine("Press 1 for Admin");
            Console.WriteLine("Press 2 for Customer");
            var a = Convert.ToInt32(Console.ReadLine());
            switch(a)
            {
                case 1:AdminDashboard.AdminMenu(myRestraunt);
                    break;
                case 2: CustomerDashboard.CustomerMenu(firstCustomer, myRestraunt);
                    break;
                default: Console.WriteLine("Please select from above options only ");
                    break;

            }






            






          
        }
    }
}
