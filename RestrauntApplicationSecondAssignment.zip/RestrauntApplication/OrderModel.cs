﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestrauntApplication
{
    class OrderModel
    {
        private int _orderID;
        private int _customerID;
        private List<int[]> _itemOrdered;

        public OrderModel(int orderID, int customerID, List<int[]> itemID)
        {
            _orderID = orderID;
            _customerID = customerID;
            _itemOrdered = itemID;
        }

        public int OrderId
        {
            set
            {
                _orderID = value;
            }
            get
            {
                return _orderID;
            }
        }
        public int CustomerId
        {
            set
            {
                _customerID = value;
            }
            get
            {
                return _customerID;
            }
        }
       
    }
}
