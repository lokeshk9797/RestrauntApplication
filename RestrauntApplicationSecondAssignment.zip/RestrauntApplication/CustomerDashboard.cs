﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestrauntApplication
{
    class CustomerDashboard
    {
        public static void CustomerMenu(CustomerModel customer, RestaurantDetails myRestraunt)
        {
            //Creating choice for User to Select 
            
            int optionSelected = 0;
            
            List<OrderModel> itemsOrdered = new List<OrderModel>();
            List<int> itemQuantity = new List<int>();
            var itemId = 0;
            var quantity = 0;
            double billAmount = 0;


            //Looping the Menu For Customer to Order
            while(true)
            {
                Console.Clear();
                Console.WriteLine("---------------- Happy Food Junction ----------------");
                Console.WriteLine("1.Book Table.");
                Console.WriteLine("2.Menu Card.");
                Console.WriteLine("3.Print Bill.");
                Console.WriteLine("4.Exit");


                Console.Write("Please choose an option  : ");
                optionSelected = Convert.ToInt32(Console.ReadLine());
                switch (optionSelected)
                {
                    case 1:
                        {
                            Console.Clear();
                            //Console.WriteLine($"No of Tables :{myRestraunt.Tables.Count}");
                            bool isRestrauntFullhouse = true;
                            foreach (var iterator in myRestraunt.Tables)
                            {
                                if (iterator.IsTableAvailable)
                                {
                                    isRestrauntFullhouse = false;
                                    Console.WriteLine($"Table No: {iterator.TableID}\t\tTable Capacity : { iterator.TableCapacity}");
                                }
                               
                            }
                            if(isRestrauntFullhouse)
                            {
                                Console.WriteLine("Sorry NO tables available right now" );
                            }
                            Console.WriteLine("Please select a table");
                            int tableNumber =Convert.ToInt32(Console.ReadLine());
                            if(myRestraunt.Tables.Count >= tableNumber && myRestraunt.Tables[tableNumber - 1].IsTableAvailable == true )
                            {
                                myRestraunt.Tables[tableNumber - 1].IsTableAvailable = false;
                                Console.WriteLine($"Table no - {tableNumber} Booked for You ");
                            }
                            else
                            {
                                Console.WriteLine("Table Not Available");
                            }
                            
                            
                            customer.TableID = tableNumber;

                        }
                        break;
                    case 2:
                        {
                            Console.Clear();
                            Console.WriteLine("---------------- Todays Food  ----------------");
                            foreach (var item in myRestraunt.ItemData)
                            {
                                if (item.IsAvailable)
                                {
                                    Console.WriteLine($"{item.ItemId}. { item.ItemName}\t\tPrice: {item.ItemPrice}");
                                }
                            }

                            var iterator = 0;
                             while(iterator<customer.MaxOrderlimit)
                            {
                                Console.WriteLine("Enter the Item Number You want to order");
                                itemId=Convert.ToInt32(Console.ReadLine());
                                
                                
                                Console.WriteLine("Enter the Quantity of items required");
                                quantity = Convert.ToInt32(Console.ReadLine());

                                billAmount += myRestraunt.ItemData[itemId-1].ItemPrice * quantity;

                                Console.WriteLine("Do you want to order Something else.....(press Y for yes)");
                                var choice = Console.ReadLine();
                                if (choice.Equals("Y") || choice.Equals("y"))
                                {
                                    iterator++;
                                }
                                else
                                {
                                    break;
                                }
                               
                            }

                        }
                        break;
                    case 3:
                        {
                            Console.Clear();
                            Console.WriteLine("------------------------Print Bill ----------------------");
                            Console.WriteLine($"Your Total Bill Amount is {billAmount}");
                            

                        }
                        break;
                    case 4:
                        {
                            Environment.Exit(0);
                        }
                        break;
                    default:
                        {
                            Console.WriteLine("\nPlease choose from above options");
                            continue;
                        }
                        

                }

                Console.Write("\n\nPress any key to Continue");
                Console.ReadKey();

            }
            
        }
    }
}
