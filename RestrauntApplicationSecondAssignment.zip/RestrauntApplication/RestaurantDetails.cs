﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestrauntApplication
{
    class RestaurantDetails
    {
        private string _restrauntName;
        private string _branchName;
        private List<ItemListModel> _items;
        private List<TableModel> _tables;

        public RestaurantDetails(string restrauntName, string branchName, List<ItemListModel> items, List<TableModel> tables)
        {
            this._restrauntName = restrauntName;
            this._branchName = branchName;
            this._items = items;
            this._tables = tables;
        }

        

        public string Name
        {
            get
            {
                return _restrauntName;
            }
        }
        public string Branch
        {
            get
            {
                return _branchName;
            }
        }
        
        public List<ItemListModel> ItemData
        {
            get
            {
                return _items;
            }
        }
        
        public List<TableModel> Tables
        {
            get
            {
                return _tables;
            }
        }


    }
}
