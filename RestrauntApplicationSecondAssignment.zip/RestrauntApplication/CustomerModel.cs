﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestrauntApplication
{
    class CustomerModel
    {
        private int _customerID;
        private string _customerName;
        private int _maxOrderLimit=2;
        private int _tableID;

        public CustomerModel(int customerID, string customerName)
        {
            this._customerID = customerID;
            this._customerName = customerName;
        }

        public int CustomerID
        {
            get
            {
                return _customerID;
            }
            set
            {
                _customerID = value;
            }
        }

        public string CustomerName
        {
            get
            {
                return _customerName;
            }
            set
            {
                _customerName = value;
            }
        }
        public int MaxOrderlimit
        {
            get
            {
                return _maxOrderLimit;
            }
        }

        public int TableID
        {
            get
            {
                return _tableID;
            }
            set
            {
                _tableID = value;
            }
        }
    }
}
