﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestrauntApplication
{
    class AdminDashboard
    {
        
        public static void AdminMenu( RestaurantDetails myRestraunt)
        {
            //Creating choice for User to Select 
            
            int optionSelected = 0;
            //Looping the Menu For Customer to Order
            while(true)
            {
                Console.Clear();
                Console.WriteLine("---------------- Happy Food Junction ----------------");
                Console.WriteLine("1.Menu Card");
                Console.WriteLine("2.Items Available Today");
                Console.WriteLine("3.Tables Details.");
                Console.WriteLine("4.Restraunt Name");
                Console.WriteLine("5.Branch Name");
                Console.WriteLine("6.Exit");


                Console.Write("Please choose an option  : ");
                optionSelected = Convert.ToInt32(Console.ReadLine());
                switch (optionSelected)
                {
                    case 1:
                        {
                            Console.Clear();
                            Console.WriteLine("---------------- Menu ----------------");
                            foreach (var iterator in myRestraunt.ItemData)
                            {
                                Console.WriteLine($"Name : { iterator.ItemName}\t\tPrice: {iterator.ItemPrice} ");
                            }

                        }
                        break;
                    case 2:
                        {
                            Console.Clear();
                            Console.WriteLine("---------------- Todays Food ----------------");
                            foreach (var iterator in myRestraunt.ItemData)
                            {
                                if (iterator.IsAvailable)
                                {
                                    Console.WriteLine($"Name : { iterator.ItemName}\t\tPrice: {iterator.ItemPrice}");
                                }
                            }
                        }
                        break;
                    case 3:
                        {
                            Console.Clear();
                            Console.WriteLine($"No of Tables :{myRestraunt.Tables.Count}");
                            foreach (var iterator in myRestraunt.Tables)
                            {
                                if (iterator.IsTableAvailable)
                                {
                                    Console.WriteLine($"Table No: {iterator.TableID}\t\tTable Capacity : { iterator.TableCapacity}\t\tStatus: Available");
                                }
                                else
                                {
                                    Console.WriteLine($"Table No: {iterator.TableID}\t\tTable Capacity : { iterator.TableCapacity}\t\tStatus: Occupied");

                                }
                            }

                        }
                        break;
                    case 4:
                        {
                            Console.Clear();
                            Console.WriteLine($"\nRestraunt Name : {myRestraunt.Name}");
                        }
                        break;
                    case 5:
                        {
                            Console.Clear();
                            Console.WriteLine($"\nBranch Name: {myRestraunt.Branch}");
                        }
                        break;
                    case 6:
                        {
                            Environment.Exit(0);
                        }
                        break;
                    default:
                        {
                            Console.WriteLine("\nPlease choose from above options");
                        }
                        break;

                }

                Console.Write("\n\nPress any key to Continue");
                //choice=Console.ReadLine();
                Console.ReadKey();

            }
            
        }
    }
}
