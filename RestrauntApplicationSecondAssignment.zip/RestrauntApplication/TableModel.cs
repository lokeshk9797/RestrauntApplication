﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestrauntApplication
{
    class TableModel
    {
        private int _tableID;
        private int _tableCapacity;
        private bool _isTableAvailable;

        public TableModel(int tableID, int tableCapacity, bool isTableAvailable)
        {
            this._tableID = tableID;
            this._tableCapacity = tableCapacity;
            this._isTableAvailable = isTableAvailable;
        }

        public int TableID
        { 
            get
            {
                return _tableID;
            }
            set
            {
                _tableID = value;
            }
        }
        public int TableCapacity
        {
            get
            {
                return _tableCapacity;
            }
            set
            {
                _tableCapacity = value;
            }
        }
        public bool IsTableAvailable
        {
            get
            {
                return _isTableAvailable;
            }
            set
            {
                _isTableAvailable = value;
            }
        }




    }
}
