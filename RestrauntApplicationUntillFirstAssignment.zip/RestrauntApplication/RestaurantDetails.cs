﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestrauntApplication
{
    class RestaurantDetails
    {
        private string restrauntName;
        private string branchName;
        private int tableCount;
        private List<ItemList> items;
        
        public RestaurantDetails(string name, string branch,int table,List<ItemList> listOfItems)
        {
            restrauntName = name;
            branchName = branch;
            tableCount = table;
            items = listOfItems;

        }

        public string Name
        {
            get
            {
                return restrauntName;
            }
        }
        public string Branch
        {
            get
            {
                return branchName;
            }
        }
        public int TableCount
        {
            get
            {
                return tableCount;
            }
        }

        public List<ItemList> ItemData
        {
            get
            {
                return items;
            }
        }
        


    }
}
