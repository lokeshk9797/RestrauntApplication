﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestrauntApplication
{
    class MenuList
    {
        
        static void Main(string[] args)
        {
            String choice = "Y";
            int optionSelected=0;

            List <ItemList> itemObject= new List<ItemList>();
            itemObject.Add(new ItemList(1, "Idli", 40.00, true));
            itemObject.Add(new ItemList(2, "Dosa", 70.00, true));
            itemObject.Add(new ItemList(3, "Tea", 15.00, false));

            RestaurantDetails Myrestraunt = new RestaurantDetails("Happy Food Junction","Mihan Branch",5,itemObject);
                       
            do
            {
                Console.Clear();
                Console.WriteLine("---------------- Happy Food Junction ----------------");
                Console.WriteLine("1.Menu Card");
                Console.WriteLine("2.Items Available Today");
                Console.WriteLine("3.List of Tables.");
                Console.WriteLine("4.Restraunt Name");
                Console.WriteLine("5.Branch Name");
                Console.WriteLine("6.Exit");

                Console.Write("Please choose an option  : ");
                optionSelected = Convert.ToInt32(Console.ReadLine());
                switch (optionSelected)
                {
                    case 1:
                        {
                            Console.Clear();
                            Console.WriteLine("---------------- Menu ----------------");
                            foreach (var iterator in Myrestraunt.ItemData)
                            {
                                Console.WriteLine($"Name : { iterator.ItemName}\t\tPrice: {iterator.ItemPrice} ");
                            }

                        }
                        break;
                    case 2:
                        {
                            Console.Clear();
                            Console.WriteLine("---------------- Todays Food ----------------");
                            foreach (var iterator in Myrestraunt.ItemData)
                            {
                                if(iterator.IsAvailable)
                                {
                                    Console.WriteLine($"Name : { iterator.ItemName}\t\tPrice: {iterator.ItemPrice}");
                                }
                            }
                        }
                        break;
                    case 3:
                        {
                            Console.Clear();
                            Console.WriteLine($"No of Tables :{Myrestraunt.TableCount}");
                        }
                        break;
                    case 4:
                        {
                            Console.Clear();
                            Console.WriteLine($"Restraunt Name : {Myrestraunt.Name}");
                        }
                        break;
                    case 5:
                        {
                            Console.Clear();
                            Console.WriteLine($"Branch Name: {Myrestraunt.Branch}");
                        }
                        break;
                    case 6:
                        {
                            Environment.Exit(0);
                        }
                        break;
                    default:
                        {
                            Console.WriteLine("Please choose from above options");
                        }
                        break;

                }

                Console.Write("\n\nPress any key to Continue");
                //choice=Console.ReadLine();
                Console.ReadKey();
                
            }
            while (choice.Equals("Y") || choice.Equals("y"));
        }
    }
}
