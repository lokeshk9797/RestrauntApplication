﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestrauntApplication
{
    class ItemList
    {
        private int itemId;
        private string itemName;
        private double itemPrice;
        private bool isAvailable;

        public int ItemId { get; set; }
        public string ItemName
        {
            set
            {
                itemName = value;
            }
            get
            {
                return itemName;
            }
        }
        public double ItemPrice
        {
            set
            {
                itemPrice = value;
            }
            get
            {
                return itemPrice;
            }
        }
        public bool IsAvailable
        {
            set
            {
                isAvailable = value;
            }
            get
            {
                return isAvailable;
            }
        }

        public ItemList(int id, string name, double price, bool available)
        {
            this.itemId = id;
            this.itemName = name;
            this.itemPrice = price;
            this.isAvailable = available;
        }
    }
}
